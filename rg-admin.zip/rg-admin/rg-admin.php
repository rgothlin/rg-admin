<?php
/**
 * Plugin Name: RG Admin
 * Plugin URI: https://gothlin.no
 * Description: Gives the admin area a new, rebranded look and feel.
 * Version: 1.1
 * Author: Rickard Gothlin
 * Author URI: https://gothlin.no
 * Text Domain: Optional. Plugin's text domain for localization. Example: mytextdomain
 * Domain Path: Optional. Plugin's relative directory path to .mo files. Example: /locale/
 * Network: Optional. Whether the plugin can only be activated network wide. Example: true
 * License: GPL2
 */

// add a new logo to the login page
function wptutsplus_login_logo() { ?>
    <style type="text/css">
        html {
            background: #f5f8fb;
        }
        
         ::selection {
            background: #444;
            color: #fff;
        }
        
         ::-moz-selection {
            background: #444;
            color: #fff;
        }
        
        body {
            background: transparent!important;
        }
        
        .login #login h1 a {
            background-image: url(<?php echo plugins_url( 'media/rg-websites-grey2.png' , __FILE__ );
            ?>);
            background-size: 150px;
            height: 150px;
            width: 150px;
        }
        
        .login #nav {
            padding: 0!important;
            margin: 20px auto 8px;
            width: 100%;
            text-align: center;
        }
        
        #login {
            width: 320px;
            padding: 0;
            margin: 8% auto 0;
            /*background-color: #278;*/
            border-radius: 10px;
            /*
            border: 2px solid #167;*/
        }
        
        .login #nav a,
        .login #backtoblog a {
            color: #1c1c1c !important;
        }
        
        .login #nav a:hover,
        .login #backtoblog a:hover {
            color: #3AB783 !important;
        }
        /* .login #backtoblog a { padding: 4px 8px; background: #389; border-radius: 5px; }*/
        /* .login #backtoblog a:hover { background: #4DA5F2; color: #fff!important; }*/
        
        .login form {
            position: relative;
            max-width: 300px;
            padding: 25px 20px 65px!important;
            box-shadow: none;
            border-radius: 5px;
            background: #f5f8fb;
            border: none!important;
            box-shadow: 0 8px 45px rgba(0, 0, 0, 0.2)!important;
        }
        
        .login label {
            color: #fff;
            font-size: 16px;
        }
        
        .login input:focus {
            box-shadow: none;
            border-color: #4DA5F2;
            color: #1c1c1c;
        }
        
        .login input {
            box-shadow: none;
            border: none;
            /* border-bottom: 2px solid #389;*/
        }
        
        .login input[type="text"],
        .login input[type="password"] {
            /*background-color: #5bc;*/
            color: #000;
            margin-top: 5px;
        }
        
        .login input[type="text"]:focus,
        .login input[type="password"]:focus {
            box-shadow: none!important;
        }
        
        .login .button-primary {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            width: 100%;
            padding: 8px 0;
            background: #3AB783!important;
            font-size: 20px;
            height: 60px !important;
            text-shadow: none!important;
            border: none!important;
            box-shadow: none;
            border-radius: 0;
            border-radius: 0 0 5px 5px!important;
        }
        
        .login .button-primary:hover {
            border: none;
            background-color: #2AA773!important;
            box-shadow: none;
        }
        
        #backtoblog {
            margin: 16px auto auto;
            position: relative;
            text-align: center;
        }

    </style>
    <?php }
add_action( 'login_enqueue_scripts', 'wptutsplus_login_logo' );

//Update Checker --- Use version 2.0 of the update checker.
require 'plugin-update-checker/plugin-update-checker.php';
	$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
		'https://bitbucket.org/rgreenberg/rg-admin/get/metadata.json',
		__FILE__,
		'rg-admin'
        );


// let's start by enqueuing our styles correctly
function wptutsplus_admin_styles() {
    wp_register_style( 'wptuts_admin_stylesheet', plugins_url( '/css/style.css', __FILE__ ) );
    wp_enqueue_style( 'wptuts_admin_stylesheet' );
}
add_action( 'admin_enqueue_scripts', 'wptutsplus_admin_styles' );

//change the footer text
function wptutsplus_admin_footer_text () {
    echo '<a href="https://gothlin.no" target="_blank" rel="nofollow">RG Websites</a>.';
}
add_filter( 'admin_footer_text', 'wptutsplus_admin_footer_text' );

function my_footer_shh() {
    remove_filter( 'update_footer', 'core_update_footer' ); 
}

add_action( 'admin_menu', 'my_footer_shh' );


function remove_dashboard_meta() {
        remove_meta_box( 'dashboard_incoming_links', 'dashboard', 'normal' );
        remove_meta_box( 'dashboard_plugins', 'dashboard', 'normal' );
        remove_meta_box( 'dashboard_primary', 'dashboard', 'normal' );
        remove_meta_box( 'dashboard_secondary', 'dashboard', 'normal' );
        remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
        remove_meta_box( 'dashboard_recent_drafts', 'dashboard', 'side' );
        remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
        remove_meta_box( 'dashboard_right_now', 'dashboard', 'normal' );
        remove_meta_box( 'dashboard_activity', 'dashboard', 'normal');//since 3.8
}
add_action( 'admin_init', 'remove_dashboard_meta' );

remove_action('welcome_panel', 'wp_welcome_panel');

//Remove WP Logo
add_action( 'admin_bar_menu', 'remove_wp_logo', 999 );

function remove_wp_logo( $wp_admin_bar ) {
	$wp_admin_bar->remove_node( 'wp-logo' );
}

//remove admin color scheme options from WordPress dashboard
remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
/*
add_action('after_setup_theme','remove_core_updates');
function remove_core_updates(){
 if( current_user_can('update_core')){return;} else {
 add_action('init', create_function('$a',"remove_action( 'init', 'wp_version_check' );"),2);
 add_filter('pre_option_update_core','__return_null');
 add_filter('pre_site_transient_update_core','__return_null');
 add_filter('pre_site_transient_update_core','remove_core_updates');
add_filter('pre_site_transient_update_plugins','remove_core_updates');
add_filter('pre_site_transient_update_themes','remove_core_updates');
 }
}*/

/*remove_action('load-update-core.php','wp_update_plugins');
add_filter('pre_site_transient_update_plugins','__return_null');*/
 //Replace 'Howdy, '
/*function replace_howdy( $wp_admin_bar ) {
 $my_account=$wp_admin_bar->get_node('my-account');
 $newtitle = str_replace( 'Howdy,', 'Greetings, ', $my_account->title );
 $wp_admin_bar->add_node( array(
 'id' => 'my-account',
 'title' => $newtitle,
 ) );
 }
 add_filter( 'admin_bar_menu', 'replace_howdy',25 );*/

/*function remove_menus(){
  
  remove_menu_page( 'index.php' );                  //Dashboard
  remove_menu_page( 'edit.php' );                   //Posts
  remove_menu_page( 'upload.php' );                 //Media
  remove_menu_page( 'edit.php?post_type=page' );    //Pages
  remove_menu_page( 'edit-comments.php' );          //Comments
  remove_menu_page( 'themes.php' );                 //Appearance
  remove_menu_page( 'plugins.php' );                //Plugins
  remove_menu_page( 'users.php' );                  //Users
  remove_menu_page( 'tools.php' );                  //Tools
  remove_menu_page( 'options-general.php' );        //Settings
  
}
add_action( 'admin_menu', 'remove_menus' );*/
